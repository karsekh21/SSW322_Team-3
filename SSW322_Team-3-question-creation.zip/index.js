const connection = require("./mongoConnection");
const questions = require("./data/questions.js");
const mongoCollections = require("./mongoCollections");
const questionsdb = mongoCollections.questions;

//C:\Program Files\MongoDB\Server\4.0\bin>mongod

async function main() {
	const db = await connection();
	
	try{
		var createMCQ;
		createMCQ = await questions.createMCQ('55555', "What is 2+2?", "1", "2", "3", "4", "5", "4");
		console.log(createMCQ);
	}
	catch(e){
		console.error(e);
	}
	
	try{
		var createShortAns;
		createShortAns = await questions.createShortAns('55555', "What is 3+6?", "9");
		console.log(createShortAns);
	}
	catch(e){
		console.error(e);
	}
	
	try{
		var createEssay;
		createEssay = await questions.createEssay('55555', "What do you want to be when you grow up and why?", "10", "100");
		console.log(createEssay);
	}
	catch(e){
		console.error(e);
	}
	
	try{
		var createTF;
		createTF = await questions.createTF('55555', "True or False: 4 + 4 = 7", "false");
		console.log(createTF);
	}
	catch(e){
		console.error(e);
	}
	
	try{
		var createRanking;
		createRanking = await questions.createRanking('55555', "Rank the numbers from biggest to smallest", "8", "6", "9", "9", "8", "6");
		console.log(createRanking);
	}
	catch(e){
		console.error(e);
	}
	
	try{
		var createMatching;
		createMatching = await questions.createMatching('55555', "Match the expression with the result", "1+3", "2+5", "3+6", "4+2", "4", "7", "9", "6");
		console.log(createMatching);
	}
	catch(e){
		console.error(e);
	}
	
	try{
		const getForm = await questions.displayForm('55555');
		console.log(getForm);
	}
	catch(e){
		console.error(e);
	}
	
	await db.serverConfig.close();
	
}

main();