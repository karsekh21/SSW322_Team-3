const connection = require("./../mongoConnection");
const c = require("./../mongoCollections");
const questions = c.questions;
const ObjectId = require('mongodb').ObjectID;

const createMCQ = async function createMCQ(formId, title, ans1, ans2, ans3, ans4, ans5, correctAns){
	if(!formId) throw "Error: no test/survey specified";
	if(!title){title = "Untitled"}
	if(correctAns != ans1 && correctAns != ans2 && correctAns != ans3 && correctAns != ans4 && correctAns != ans5) throw "Error: correct answer does not exist";
	const questionCollection = await questions();
	let newQuestion = {
		formId: formId,
		title: title,
		ans1: ans1,
		ans2: ans2,
		ans3: ans3,
		ans4: ans4,
		ans5: ans5,
		correctAns: correctAns
	}
	const insertInfo = await questionCollection.insertOne(newQuestion);
	if (insertInfo.insertedCount === 0) throw "Could not add question";
	const newId = insertInfo.insertedId;
	return newQuestion;
}

const createShortAns = async function createShortAns(formId, title, correctAns){
	if(!formId) throw "Error: no test/survey specified";
	if(!title){title = "Untitled"}
	const questionCollection = await questions();
	let newQuestion = {
		formId: formId,
		title: title,
		response: " ",
		correctAns: correctAns
	}
	const insertInfo = await questionCollection.insertOne(newQuestion);
	if (insertInfo.insertedCount === 0) throw "Could not add question";
	const newId = insertInfo.insertedId;
	return newQuestion;
}

const createEssay = async function createEssay(formId, title, minWordCount, maxWordCount){
	if(!formId) throw "Error: no test/survey specified";
	if(!title){title = "Untitled"}
	const questionCollection = await questions();
	let newQuestion = {
		formId: formId,
		title: title,
		response: " ",
		minWordCount: minWordCount,
		maxWordCount: maxWordCount
	}
	const insertInfo = await questionCollection.insertOne(newQuestion);
	if (insertInfo.insertedCount === 0) throw "Could not add question";
	const newId = insertInfo.insertedId;
	return newQuestion;
}

const createTF = async function createTF(formId, title, correctAns){
	if(!formId) throw "Error: no test/survey specified";
	if(!title){title = "Untitled"}
	if(correctAns != "true" && correctAns != "false") throw "Error: correct answer must be true or false";
	const questionCollection = await questions();
	let newQuestion = {
		formId: formId,
		title: title,
		t: "true",
		f: "false",
		correctAns: correctAns
	}
	const insertInfo = await questionCollection.insertOne(newQuestion);
	if (insertInfo.insertedCount === 0) throw "Could not add question";
	const newId = insertInfo.insertedId;
	return newQuestion;
}

const createRanking = async function createRanking(formId, title, ans1, ans2, ans3, best, middle, worst){
	if(!formId) throw "Error: no test/survey specified";
	if(!title){title = "Untitled"}
	const questionCollection = await questions();
	let newQuestion = {
		formId: formId,
		title: title,
		ans1: ans1,
		ans2: ans2,
		ans3: ans3,
		best: best,
		middle: middle,
		worst: worst
	}
	const insertInfo = await questionCollection.insertOne(newQuestion);
	if (insertInfo.insertedCount === 0) throw "Could not add question";
	const newId = insertInfo.insertedId;
	return newQuestion;
}

const createMatching = async function createMatching(formId, title, ans1, ans2, ans3, ans4, a, b, c, d){
	if(!formId) throw "Error: no test/survey specified";
	if(!title){title = "Untitled"}
	const questionCollection = await questions();
	let newQuestion = {
		formId: formId,
		title: title,
		ans1: ans1,
		ans2: ans2,
		ans3: ans3,
		ans4: ans4,
		a: a,
		b: b,
		c: c,
		d: d
	}
	const insertInfo = await questionCollection.insertOne(newQuestion);
	if (insertInfo.insertedCount === 0) throw "Could not add question";
	const newId = insertInfo.insertedId;
	return newQuestion;
}

const displayForm = async function displayForm(id){
	if(!id) throw "Error: id not provided";
	const questionCollection = await questions();
	const getForm = await questionCollection.find({ formId: id}).toArray();
	if(getForm === null) throw "Error: No form with that id";
	return getForm;
}

module.exports = {
	createMCQ,
	createShortAns,
	createEssay,
	createTF,
	createRanking,
	createMatching,
	displayForm
}