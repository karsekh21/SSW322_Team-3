var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

//Get HELLO WORLD PAGE
router.get('/helloworld', function(req,res) {
  res.render('helloworld', {title: 'Hello, World!' });
});

//Get Userlist page
router.get('/questionlist', function(req,res) {
  var db = req.db;
  var collection = db.get('questioncollection');
  collection.find({}, {}, function(e, docs) {
    res.render('questionlist', {
      "questionlist" : docs
    });
  });
});

//Get new user page
router.get('/newquestion', function(req, res) {
  res.render('newquestion', { title: 'Add New Question'});
});

/* POST to Add User Service */
router.post('/addquestion', function(req, res) {

  // Set our internal DB variable
  var db = req.db;

  // Get our form values. These rely on the "name" attributes
  var formId = req.body.addquestion;
  // var questiontype = req.body.questiontype;
  var formTitle = req.body.newQuestion;
  var newChoice = req.body.mcChoice1;
  var newChoice2 = req.body.mcChoice2;
  var newChoice3 = req.body.mcChoice3;
  var newChoice4 = req.body.mcChoice4;
  // var userName = req.body.username;
  // var userEmail = req.body.useremail;

  // Set our collection
  var collection = db.get('questioncollection');

  // Submit to the DB
  collection.insert({
      // "questionType" : questiontype,
      "formId" : formId,
      "title" : formTitle,
      "choice 1": newChoice,
      "choice 2": newChoice2,
      "choice 3": newChoice3,
      "choice 4": newChoice4
  }, function (err, doc) {
      if (err) {
          // If it failed, return error
          res.send("There was a problem adding the information to the database.");
      }
      else {
          // And forward to success page
          res.redirect("questionlist");
      }
  });
});





// For True/False
router.get('/newtruefalse', function(req, res) {
  res.render('newtruefalse', { title: 'Add New True/False'});
});

router.post('/addtruefalse', function(req, res) {

  // Set our internal DB variable
  var db = req.db;

  // Get our form values. These rely on the "name" attributes
  var formId = req.body.addtruefalse;
  var formTitle = req.body.newTrueFalse;

  // Set our collection
  var collection = db.get('questioncollection');

  // Submit to the DB
  collection.insert({
      "formId" : formId,
      "title" : formTitle,
      "truefalse" : true
  }, function (err, doc) {
      if (err) {
          // If it failed, return error
          res.send("There was a problem adding the information to the database.");
      }
      else {
          // And forward to success page
          res.redirect("questionlist");
      }
  });
});




// For Essay
router.get('/newessay', function(req, res) {
  res.render('newessay', { title: 'Add New Essay'});
});

router.post('/addessay', function(req, res) {

  // Set our internal DB variable
  var db = req.db;

  // Get our form values. These rely on the "name" attributes
  var formId = req.body.addessay;
  var formTitle = req.body.newEssay;

  // Set our collection
  var collection = db.get('questioncollection');

  // Submit to the DB
  collection.insert({
      "formId" : formId,
      "title" : formTitle,
      "essay" : true
  }, function (err, doc) {
      if (err) {
          // If it failed, return error
          res.send("There was a problem adding the information to the database.");
      }
      else {
          // And forward to success page
          res.redirect("questionlist");
      }
  });
});

module.exports = router;
