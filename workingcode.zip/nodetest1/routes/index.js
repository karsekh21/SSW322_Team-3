let express = require('express');
let router = express.Router();
let currTest = null;
let currnum;
let currSurvey = null; // 04/14/19

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('home');
});

//Get HELLO WORLD PAGE
router.get('/helloworld', function(req,res) {
  res.render('helloworld', {title: 'Hello, World!' });
});


// Display (load) a particlar test
router.post('/testquestionlist', async function(req,res) {
  let db = req.db;
  let collection = db.get('testcollection'); // 4/10/19
  let targetAccessCode = req.body.targetTestAccessCode;
  console.log(targetAccessCode);
  
  let testToPass = await collection.findOne({"testAccessCode": targetAccessCode});
    // if (testToPass === null) {
    //   alert("Invalid access code!");
    // }

  // try {
  //   let testToPass = await collection.findOne({"testAccessCode": targetAccessCode});
  //   if (testToPass === null) {
  //     alert("Invalid access code!");
  //   }
  //   console.log(testToPass);
  // } catch(e) {
  //   alert("Invalid access code!");
  //   console.log("Alert!");
  // }
  
  

  res.render('testquestionlist', {testquestionlist: testToPass});

});

// MAKER TEST QUESTION LIST
router.post('/makertestquestionlist', async function(req,res) {
  let db = req.db;
  let collection = db.get('testcollection'); // 4/10/19
  let targetAccessCode = req.body.targetTestAccessCode;
  console.log(targetAccessCode);
  
  let testToPass = await collection.findOne({"testAccessCode": targetAccessCode});
  currTest = testToPass;

  

  res.render('makertestquestionlist', {testquestionlist: testToPass});

});

// MAKER SURVEY QUESTION LIST
router.post('/makersurveyquestionlist', async function(req,res) {
  let db = req.db;
  let collection = db.get('surveycollection'); // 4/22/19
  let targetAccessCode = req.body.targetSurveyAccessCode;
  console.log(targetAccessCode);
  
  let surveyToPass = await collection.findOne({"surveyAccessCode": targetAccessCode});
  currSurvey = surveyToPass;
  console.log("I am here right now");
  console.log(currSurvey);

  

  res.render('makersurveyquestionlist', {surveyquestionlist: surveyToPass});

});

// router.post("modifytest", async function(req, res) {
  
// })

router.get('/modifynewquestion', function(req, res) {
  res.render('modifynewquestion');
});

router.post('/modifynewquestion', async function(req, res) {
  // Get our form values. These rely on the "name" attributes
  let formTitle = req.body.newQuestion;
  let newChoice = req.body.mcChoice1;
  let newChoice2 = req.body.mcChoice2;
  let newChoice3 = req.body.mcChoice3;
  let newChoice4 = req.body.mcChoice4;
  let newChoice5 = req.body.mcChoice5;
  let answer = req.body.answer;

  // Set our collection
  let collection = req.db.get('testcollection');

  let newEntry = {
    "title" : formTitle,
    "choice 1": newChoice,
    "choice 2": newChoice2,
    "choice 3": newChoice3,
    "choice 4": newChoice4,
    "choice 5": newChoice5,
    "Correct Answer": answer,
    "type" : "mc" 
  };

  const updated = await collection.findOneAndUpdate(
    { testAccessCode : currTest.testAccessCode },
    { $set : { [`questions.${currnum}`] : newEntry }},
  );

  console.log(updated);

  res.redirect("/makertestlist");
})

// List of Tests
// router.get('/testlist', function(req,res) {
//   let db = req.db;
//   let collection = db.get('testcollection'); // 4/10/19
//   collection.find({}, {}, function(e, docs) {
//     res.render('testquestionlist', {
//       "testquestionlist" : docs
//     });
//   });
// });

// router.get('/surveyquestionlist', function(req,res) {
//   let db = req.db;
//   let collection = db.get('surveyquestioncollection');
//   collection.find({}, {}, function(e, docs) {
//     res.render('surveyquestionlist', {
//       "surveyquestionlist" : docs
//     });
//   });
// });

// Display (load) a particlar survey
router.post('/surveyquestionlist', async function(req,res) {
  let db = req.db;
  let collection = db.get('surveycollection'); // 4/10/19
  let surveyTargetAccessCode = req.body.targetSurveyAccessCode;
  
  let surveyToPass = await collection.findOne({"surveyAccessCode": surveyTargetAccessCode});
  console.log(surveyToPass);

  res.render('surveyquestionlist', {surveyquestionlist: surveyToPass});

});

// //Get new user page
router.get('/newquestion', function(req, res) {
  res.render('newquestion', { title: 'Add New Question'});
});

/* POST to Add User Service */
router.post('/addquestion', async function(req, res) {

  // Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  let formId = req.body.addquestion;
  let formTitle = req.body.newQuestion;
  let newChoice = req.body.mcChoice1;
  let newChoice2 = req.body.mcChoice2;
  let newChoice3 = req.body.mcChoice3;
  let newChoice4 = req.body.mcChoice4;
  let newChoice5 = req.body.mcChoice5;
  let answer = req.body.answer;
  // let userName = req.body.username;
  // let userEmail = req.body.useremail;



  let newEntry = {
    "title" : formTitle,
    "choice 1": newChoice,
    "choice 2": newChoice2,
    "choice 3": newChoice3,
    "choice 4": newChoice4,
    "choice 5": newChoice5,
    "Correct Answer": answer,
    "type" : "mc" 
  }

  // let targetAccessCode = req.body.targetTestAccessCode;
  // console.log(targetAccessCode);
  
  // let testToPass = await collection.findOne({"testAccessCode": targetAccessCode});
  // currTest = testToPass;

  // Set our collection
  let collection = await db.get('testcollection');

  await collection.findOneAndUpdate(
    {"testFormName": currTest["testFormName"]},
    { $addToSet: {"questions": newEntry} }, {returnOriginal: false}, function (err, doc) {
          if (err) {
              // If it failed, return error
              res.send("There was a problem adding the information to the database.");
          }
          else {
              // And forward to success page
              res.redirect("testquestions");
          }
    });
  // Submit to the DB
  // collection.insert({
  //     "formId" : formId,
  //     "title" : formTitle,
  //     "choice 1": newChoice,
  //     "choice 2": newChoice2,
  //     "choice 3": newChoice3,
  //     "choice 4": newChoice4,
  //     "choice 5": newChoice5,
  //     "Correct Answer": answer,
  //     "testMultChoice": true
  // }, function (err, doc) {
  //     if (err) {
  //         // If it failed, return error
  //         res.send("There was a problem adding the information to the database.");
  //     }
  //     else {
  //         // And forward to success page
  //         res.redirect("testquestions");
  //     }
  // });
});




// For Survey Multiple Choice (newmultchoice2)
router.get('/newmultchoice2', function(req, res) {
  res.render('newmultchoice2', { title: 'Add New Survey Mult Choice Question'});
});

/* POST to Add User Service */
router.post('/addquestion2', function(req, res) {

  // Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  // let formId = req.body.addquestion;
  let formTitle = req.body.newQuestion;
  let newChoice = req.body.mcChoice1;
  let newChoice2 = req.body.mcChoice2;
  let newChoice3 = req.body.mcChoice3;
  let newChoice4 = req.body.mcChoice4;
  let newChoice5 = req.body.mcChoice5;
  let answer = req.body.answer;
  // let userName = req.body.username;
  // let userEmail = req.body.useremail;


  // Set our collection
  let collection = db.get('surveycollection');

  let newSurveyMultChoiceEntry = {
    "title" : formTitle,
    "choice 1": newChoice,
    "choice 2": newChoice2,
    "choice 3": newChoice3,
    "choice 4": newChoice4,
    "choice 5": newChoice5,
    "Correct Answer": answer,
    "type": "smc"
  }

  // Submit to the DB

  collection.findOneAndUpdate(
    {"surveyFormName": currSurvey["surveyFormName"]},
    { $addToSet: {"questions": newSurveyMultChoiceEntry} }, {returnOriginal: false}, function (err, doc) {
          if (err) {
              // If it failed, return error
              res.send("There was a problem adding the information to the database.");
          }
          else {
              // And forward to success page
              res.redirect("surveyquestions");
          }
    });

  // collection.insert({
  //     // "formId" : formId,
  //     "title" : formTitle,
  //     "choice 1": newChoice,
  //     "choice 2": newChoice2,
  //     "choice 3": newChoice3,
  //     "choice 4": newChoice4,
  //     "choice 5": newChoice5,
  //     "Correct Answer": answer,
  //     "surveyMultChoice": true
  // }, function (err, doc) {
  //     if (err) {
  //         // If it failed, return error
  //         res.send("There was a problem adding the information to the database.");
  //     }
  //     else {
  //         // And forward to success page
  //         res.redirect("surveyquestions");
  //     }
  // });
});





// For True/False
router.get('/newtruefalse', function(req, res) {
  res.render('newtruefalse', { title: 'Add New True/False'});
});

router.post('/addtruefalse', function(req, res) {

  // Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  let formId = req.body.formId;
  let formTitle = req.body.newTrueFalse;

    // Set our collection
    let collection = db.get('surveycollection');

    // Submit to the DB
    let newSurveyTrueFalseEntry = {
        // "correctAnswer2" : correctAnswer2,
        "formId" : formId,
        "title" : formTitle,
        "type" : "stf",
    }
  
    collection.findOneAndUpdate(
      {"surveyFormName": currSurvey["surveyFormName"]},
      { $addToSet: {"questions": newSurveyTrueFalseEntry} }, {returnOriginal: false}, function (err, doc) {
            if (err) {
                // If it failed, return error
                res.send("There was a problem adding the information to the database.");
            }
            else {
                // And forward to success page
                res.redirect("surveyquestions");
            }
      });
});




// For Essay
router.get('/newessay', function(req, res) {
  res.render('newessay', { title: 'Add New Essay'});
});

router.post('/addessay', function(req, res) {

  // Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  let formId = req.body.formId;
  let formTitle = req.body.newEssay;
  let minWordCount = req.body.minWordCount;
  let maxWordCount = req.body.maxWordCount;

  // Set our collection
  let collection = db.get('testcollection');

  // Submit to the DB
  let newEntry = {
      "minWordCount" : minWordCount,
      "maxWordCount" : maxWordCount,
      "formId" : formId,
      "title" : formTitle,
      "type" : "es",
  };

  collection.findOneAndUpdate(
  {"testFormName": currTest["testFormName"]},
  { $addToSet: {"questions": newEntry} }, {returnOriginal: false}, function (err, doc) {
        if (err) {
            // If it failed, return error
            res.send("There was a problem adding the information to the database.");
        }
        else {
            // And forward to success page
            res.redirect("testquestions");
        }
  });

});

//For Survey Essay
router.get('/newsurveyessay', function(req, res) {
  res.render('newsurveyessay', { title: 'Add New Essay'});
});

router.post('/addsurveyessay', function(req, res) {

  // Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  let formId = req.body.formId;
  let formTitle = req.body.newEssay;
  let minWordCount = req.body.minWordCount;
  let maxWordCount = req.body.maxWordCount;

  // Set our collection
  // Set our collection
  let collection = db.get('surveycollection');

  // Submit to the DB
  let newSurveyEssayEntry = {
      "minWordCount" : minWordCount,
      "maxWordCount" : maxWordCount,
      "formId" : formId,
      "title" : formTitle,
      "type" : "ses",
  }

  collection.findOneAndUpdate(
  {"surveyFormName": currSurvey["surveyFormName"]},
  { $addToSet: {"questions": newSurveyEssayEntry} }, {returnOriginal: false}, function (err, doc) {
        if (err) {
            // If it failed, return error
            res.send("There was a problem adding the information to the database.");
        }
        else {
            // And forward to success page
            res.redirect("surveyquestions");
        }
  });
});


// For Short Answer
router.get('/newshortanswer', function(req, res) {
  res.render('newshortanswer', { title: 'Add New Short Answer'});
});

router.post('/addshortanswer', function(req, res) {

  // Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  let formId = req.body.formId;
  let formTitle = req.body.newShortAnswer;
  let minWordCount = req.body.minWordCount;
  let maxWordCount = req.body.maxWordCount;

  // Set our collection
  let collection = db.get('testcollection');

  // Submit to the DB
  let newEntry = {
      "minWordCount" : minWordCount,
      "maxWordCount" : maxWordCount,
      "formId" : formId,
      "title" : formTitle,
      "type" : "sa",
  };

  collection.findOneAndUpdate(
    {"testFormName": currTest["testFormName"]},
    { $addToSet: {"questions": newEntry} }, {returnOriginal: false}, function (err, doc) {
          if (err) {
              // If it failed, return error
              res.send("There was a problem adding the information to the database.");
          }
          else {
              // And forward to success page
              res.redirect("testquestions");
          }
    });
});

// For survey short answer
router.get('/newsurveyshortanswer', function(req, res) {
  res.render('newsurveyshortanswer', { title: 'Add New Short Answer'});
});

router.post('/addsurveyshortanswer', function(req, res) {

  // Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  let formId = req.body.formId;
  let formTitle = req.body.newShortAnswer;
  let minWordCount = req.body.minWordCount;
  let maxWordCount = req.body.maxWordCount;

    // Set our collection
    let collection = db.get('surveycollection');

    // Submit to the DB
    let newSurveyShortAnswer = {
        "minWordCount" : minWordCount,
        "maxWordCount" : maxWordCount,
        "formId" : formId,
        "title" : formTitle,
        "type" : "ssa",
    }
  
    collection.findOneAndUpdate(
      {"surveyFormName": currSurvey["surveyFormName"]},
      { $addToSet: {"questions": newSurveyShortAnswer} }, {returnOriginal: false}, function (err, doc) {
            if (err) {
                // If it failed, return error
                res.send("There was a problem adding the information to the database.");
            }
            else {
                // And forward to success page
                res.redirect("surveyquestions");
            }
      });
});

// For True or False (TrueFalse2) for TESTS!!!
// For True/False
router.get('/newtruefalse2', function(req, res) {
  res.render('newtruefalse2', { title: 'Add New True or False'});
});

router.post('/addtruefalse2', function(req, res) {

  // Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  let formId2 = req.body.formId2;
  let formTitle2 = req.body.newTrueFalse2;
  let correctAnswer2 = req.body.correctAnswer2;

  // Set our collection
  let collection = db.get('testcollection');

  // Submit to the DB
  let newEntry = {
      "correctAnswer2" : correctAnswer2,
      "formId2" : formId2,
      "title2" : formTitle2,
      "type" : "tf",
  };

  collection.findOneAndUpdate(
    {"testFormName": currTest["testFormName"]},
    { $addToSet: {"questions": newEntry} }, {returnOriginal: false}, function (err, doc) {
          if (err) {
              // If it failed, return error
              res.send("There was a problem adding the information to the database.");
          }
          else {
              // And forward to success page
              res.redirect("testquestions");
          }
    });
});




// Matching Question Route
router.get('/newMatching', function(req, res) {
  res.render('newMatching', { title: 'Add New Question'});
});

/* POST to Add User Service */
router.post('/addMatching', function(req, res) {

  // Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  let formId = req.body.addMatching;
  let formTitle = req.body.newMatching;
  let firstKey = req.body.firstKey;
  let firstValue = req.body.firstValue;
  let secondKey = req.body.secondKey;
  let secondValue = req.body.secondValue;
  let thirdKey = req.body.thirdKey;
  let thirdValue = req.body.thirdValue;
  
  // Set our collection
  let collection = db.get('testcollection');

  // Submit to the DB
  let newEntry = {
      "formId" : formId,
      "title" : formTitle,
      "firstKey": firstKey,
      "firstValue": firstValue,
      "secondKey": secondKey,
      "secondValue": secondValue,
      "thirdKey": thirdKey,
      "thirdValue": thirdValue,
	    "type" : "ma"
  };

  collection.findOneAndUpdate(
    {"testFormName": currTest["testFormName"]},
    { $addToSet: {"questions": newEntry} }, {returnOriginal: false}, function (err, doc) {
          if (err) {
              // If it failed, return error
              res.send("There was a problem adding the information to the database.");
          }
          else {
              // And forward to success page
              res.redirect("testquestions");
          }
    });
});

// Matching Question For Survey
router.get('/newsurveymatching', function(req, res) {
  res.render('newsurveymatching', { title: 'Add New Question'});
});

/* POST to Add User Service */
router.post('/addSurveyMatching', function(req, res) {

  // Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  let formId = req.body.addMatching;
  let formTitle = req.body.newMatching;
  let firstKey = req.body.firstKey;
  let firstValue = req.body.firstValue;
  let secondKey = req.body.secondKey;
  let secondValue = req.body.secondValue;
  let thirdKey = req.body.thirdKey;
  let thirdValue = req.body.thirdValue;
  
    // Set our collection
    let collection = db.get('surveycollection');

    // Submit to the DB
    let newSurveyMatchingEntry = {
        "formId" : formId,
        "title" : formTitle,
        "firstKey": firstKey,
        "firstValue": firstValue,
        "secondKey": secondKey,
        "secondValue": secondValue,
        "thirdKey": thirdKey,
        "thirdValue": thirdValue,
        "type": "sma"
    }
  
    collection.findOneAndUpdate(
      {"surveyFormName": currSurvey["surveyFormName"]},
      { $addToSet: {"questions": newSurveyMatchingEntry} }, {returnOriginal: false}, function (err, doc) {
            if (err) {
                // If it failed, return error
                res.send("There was a problem adding the information to the database.");
            }
            else {
                // And forward to success page
                res.redirect("surveyquestions");
            }
      });
});




// To display answer key
// For True or False (TrueFalse2)
// For True/False
router.get('/answerlist', function(req, res) {
  res.render('answerlist', { title: 'Answer Key'});
});

// router.post('/addtruefalse2', function(req, res) {

//   // Set our internal DB variable
//   let db = req.db;

//   // Get our form values. These rely on the "name" attributes
//   let formId2 = req.body.formId2;
//   let formTitle2 = req.body.newTrueFalse2;
//   let correctAnswer2 = req.body.correctAnswer2;

//   // Set our collection
//   let collection = db.get('questioncollection');

//   // Submit to the DB
//   collection.insert({
//       "correctAnswer2" : correctAnswer2,
//       "formId2" : formId2,
//       "title2" : formTitle2,
//       "truefalse2" : true,
//   }, function (err, doc) {
//       if (err) {
//           // If it failed, return error
//           res.send("There was a problem adding the information to the database.");
//       }
//       else {
//           // And forward to success page
//           res.redirect("questionlist");
//       }
//   });
// });

router.get('/newRanking', function(req, res) {
  res.render('newRanking', { title: 'Add New Question'});
});

/* POST to Add User Service */
router.post('/addRanking', function(req, res) {

  // Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  let formId = req.body.addRanking;
  let formTitle = req.body.newRanking;
  let bestChoice = req.body.bestChoice;
  let middleChoice = req.body.middleChoice;
  let worstChoice = req.body.worstChoice;

  // Set our collection
  let collection = db.get('testcollection');

  // Submit to the DB
  let newEntry = {
      "formId" : formId,
      "title" : formTitle,
      "best": bestChoice,
      "middle": middleChoice,
      "worst": worstChoice,
	    "type": "ra"
  };

  collection.findOneAndUpdate(
    {"testFormName": currTest["testFormName"]},
    { $addToSet: {"questions": newEntry} }, {returnOriginal: false}, function (err, doc) {
          if (err) {
              // If it failed, return error
              res.send("There was a problem adding the information to the database.");
          }
          else {
              // And forward to success page
              res.redirect("testquestions");
          }
    });
});

// Ranking Question For Survey
router.get('/newsurveyranking', function(req, res) {
  res.render('newsurveyranking', { title: 'Add New Question'});
});

/* POST to Add User Service */
router.post('/addSurveyRanking', function(req, res) {

  // Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  let formId = req.body.addRanking;
  let formTitle = req.body.newRanking;
  let bestChoice = req.body.bestChoice;
  let middleChoice = req.body.middleChoice;
  let worstChoice = req.body.worstChoice;

  // Set our collection
  let collection = db.get('surveycollection');

  // Submit to the DB
  let newSurveyRankingEntry = {
      "formId" : formId,
      "title" : formTitle,
      "best": bestChoice,
      "middle": middleChoice,
      "worst": worstChoice,
	    "type": "sra"
  }

  collection.findOneAndUpdate(
    {"surveyFormName": currSurvey["surveyFormName"]},
    { $addToSet: {"questions": newSurveyRankingEntry} }, {returnOriginal: false}, function (err, doc) {
          if (err) {
              // If it failed, return error
              res.send("There was a problem adding the information to the database.");
          }
          else {
              // And forward to success page
              res.redirect("surveyquestions");
          }
    });
});




// Test or Survey Route for Makers
router.get('/testorsurvey', function(req, res) {
  res.render('testorsurvey', { title: 'Test Or Survey'});
});

// Test or Survey Route for Takers
router.get('/takertestorsurvey', function(req, res) {
  res.render('takertestorsurvey', { title: 'Taker Test Or Survey'});
});


router.get('/testformname', function(req, res) {
  res.render('testformname', { title: 'Name Your Form'});
});

// Name Your Form for Tests
router.post('/testformname', async function(req, res) {

  let testFormName = req.body.newTestFormName;
  let accessCode = req.body.testAccessCode;

  let db = req.db;

  let collection = db.get('testcollection');

  collection.insert({
    "formType": "Test",
    "testFormName": testFormName,
    "testAccessCode": accessCode,
    "questions": []
  });

  currTest = await collection.findOne({"testFormName": testFormName});
  console.log(currTest);

  res.redirect('testquestions');
});




// Same as above (naming forms) but for surveys
router.get('/surveyformname', function(req, res) {
  res.render('surveyformname', { title: 'Name Your Form'});
});

// Name Your Form for Surveys
router.post('/surveyformname', async function(req, res) {

  let surveyFormName = req.body.newSurveyFormName;
  let accessCode = req.body.surveyAccessCode;

  let db = req.db;

  let collection = db.get('surveycollection');

  collection.insert({
    "formType": "Survey",
    "surveyFormName": surveyFormName,
    "surveyAccessCode": accessCode,
    "questions": []
  });

  currSurvey = await collection.findOne({"surveyFormName": surveyFormName});
  console.log(currSurvey);

  res.redirect('surveyquestions');
});

// Maker or Taker Views
router.get('/makerortaker', function(req, res) {
  res.render('makerortaker', { title: 'Maker or Take'});
});

// Test or Survey Route
// router.get('/selecttesttotake', function(req, res) {
//   res.render('selecttesttotake', { title: 'Select a Test'});
// });

// Written on 04/15/19
router.get('/testlist', function(req,res) {
  let db = req.db;
  let collection = db.get('testcollection'); // 4/10/19
  collection.find({}, {}, function(e, docs) {
    res.render('testlist', {
      "testlist" : docs
    });
    // for (i = 0; i < testlist.length; i++) {
    //   let strLink = testlist[i].testFormName;
    //   list += strLink.link('/makerortaker') + "<br>";
    // }
  });
});

// Maker Test List
router.get('/makertestlist', function(req,res) {
  let db = req.db;
  let collection = db.get('testcollection'); // 4/10/19
  collection.find({}, {}, function(e, docs) {
    res.render('makertestlist', {
      "testlist" : docs
    });
    // for (i = 0; i < testlist.length; i++) {
    //   let strLink = testlist[i].testFormName;
    //   list += strLink.link('/makerortaker') + "<br>";
    // }
  });
});

// Maker Survey List
router.get('/makersurveylist', function(req,res) {
  let db = req.db;
  let collection = db.get('surveycollection'); // 4/22/19
  collection.find({}, {}, function(e, docs) {
    res.render('makersurveylist', {
      "surveylist" : docs
    });
    // for (i = 0; i < testlist.length; i++) {
    //   let strLink = testlist[i].testFormName;
    //   list += strLink.link('/makerortaker') + "<br>";
    // }
  });
});

// The same for surveys
router.get('/surveylist', function(req,res) {
  let db = req.db;
  let collection = db.get('surveycollection'); // 4/10/19
  collection.find({}, {}, function(e, docs) {
    res.render('surveylist', {
      "surveylist" : docs
    });
  });
});

// Test questions
router.get('/testquestions', function(req, res) {
  res.render('testquestions', { title: 'Test Or Survey'});
});


// Question Selection for Index
router.get('/surveyquestions', function(req, res) {
  res.render('surveyquestions', { title: 'Survey Questions'});
});

router.get('/enteraccesscode', function(req, res) {
  res.render('enteraccesscode', { title: 'Enter Access Code'});
});

router.get('/surveyenteraccesscode', function(req, res) {
  res.render('surveyenteraccesscode', { title: 'Survey Enter Access Code'});
});




// TAKE an exam
router.post('/testquestionlist', function(req, res) { // not sure if this should be testquestionlist or a new route

  // Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  let formId = req.body.formId;
  let formTitle = req.body.newEssay;
  let minWordCount = req.body.minWordCount;
  let maxWordCount = req.body.maxWordCount;

  // Set our collection
  let collection = db.get('testcollection');

  // Submit to the DB
  let newEntry = {
      "minWordCount" : minWordCount,
      "maxWordCount" : maxWordCount,
      "formId" : formId,
      "title" : formTitle,
      "type" : "es",
  };

  collection.findOneAndUpdate(
  {"testFormName": currTest["testFormName"]},
  { $addToSet: {"questions": newEntry} }, {returnOriginal: false}, function (err, doc) {
        if (err) {
            // If it failed, return error
            res.send("There was a problem adding the information to the database.");
        }
        else {
            // And forward to success page
            res.redirect("testquestions");
        }
  });

});

// Modify a test
router.post("/newquestion")



// Maker testquestionlist route (for loading)
router.get('/makertestquestionlist', function(req, res) {
  res.render('makertestquestionlist', { title: 'Maker Test Question List'});
});

router.get('/testcreatetestview', function(req, res) {
  res.render('testcreatetestview', { title: 'Test Create Test View'});
});

router.get('/questionmodify', function(req, res) {
  res.render('questionmodify', { title: 'Modify Question'});
});

router.post('/questionmodify', function (req, res) {
  const { questionnumber } = req.body;
  currnum = questionnumber - 1;
  switch (currTest.questions[currnum].type) {
    case "mc":
      res.redirect('/modifynewquestion');
      break;
    case "smc":
      res.redirect('/modifynewmultchoice2');
      break;
    case "tf": 
      res.redirect('/modifynewtruefalse2');
      break;
    case "stf":
      res.redirect('/modifynewtruefalse');
      break;
    case "es":
      res.redirect('/modifynewessay'); // failed to look up view - WHY
      break;
    case "ses":
      res.redirect('/modifynewsurveyessay');
      break;
    case "sa":
      res.redirect('/modifynewshortanswer');
      break;
    case "ssa":
      res.redirect('/modifynewsurveyshortanswer');
      break;
    case "ma":
      res.redirect('/modifynewmatching');
      break;
    case "sma":
      res.redirect('/modifynewsurveymatching');
      break;
    case "ra":
      res.redirect('/modifynewranking');
      break;
    case "sra":
      res.redirect('/modifynewsurveyranking');
      break;
    default:
      res.render('questionmodify');
      break;
  }
})

router.get('/surveyquestionmodify', function(req, res) {
  res.render('surveyquestionmodify', { title: 'Modify Survey Question'});
});

router.post('/surveyquestionmodify', function (req, res) {
  const { questionnumber } = req.body;
  currnum = questionnumber - 1;
  switch (currSurvey.questions[currnum].type) {
    case "mc":
      res.redirect('/modifynewquestion');
      break;
    case "smc":
      res.redirect('/modifynewmultchoice2');
      break;
    case "tf": 
      res.redirect('/modifynewtruefalse2');
      break;
    case "stf":
      res.redirect('/modifynewtruefalse');
      break;
    case "es":
      res.redirect('/modifynewessay'); // failed to look up view - WHY
      break;
    case "ses":
      res.redirect('/modifynewsurveyessay');
      break;
    case "sa":
      res.redirect('/modifynewshortanswer');
      break;
    case "ssa":
      res.redirect('/modifynewsurveyshortanswer');
      break;
    case "ma":
      res.redirect('/modifynewmatching');
      break;
    case "sma":
      res.redirect('/modifynewsurveymatching');
      break;
    case "ra":
      res.redirect('/modifynewranking');
      break;
    case "sra":
      res.redirect('/modifynewsurveyranking');
      break;
    default:
      res.render('surveyquestionmodify');
      break;
  }
})

router.get('/selectquestiontype', function(req, res) {
  res.render('selectquestiontype', { title: 'Select Question Type'});
});

router.get('/makerenteraccesscode', function(req, res) {
  res.render('makerenteraccesscode', { title: 'Maker Enter Access Code'});
});

router.post('/questionsofspecifiedtype', function(req, res) {
  let chosenType = req.body.questionType;
  res.render('questionsofspecifiedtype', {chosenType : chosenType});
});

// 12 modification routes
// TESTS
// router.get('/modifynewquestion', function(req, res) {
//   res.render('modifynewquestion', { title: 'Modify New Question '});
// });

router.get('/modifynewessay', function(req, res) {
  res.render('modifynewessay', { title: 'Modify New Essay'});
});

router.post('/modifynewessay', async function(req, res) {
  // Get our form values. These rely on the "name" attributes
   // Set our internal DB 
   let db = req.db;

   // Get our form values. These rely on the "name" attributes
   let formId = req.body.formId;
   let formTitle = req.body.newEssay;
   let minWordCount = req.body.minWordCount;
   let maxWordCount = req.body.maxWordCount;
 
   // Set our collection
   let collection = db.get('testcollection');
 
   // Submit to the DB
   let newEntry = {
       "minWordCount" : minWordCount,
       "maxWordCount" : maxWordCount,
       "formId" : formId,
       "title" : formTitle,
       "type" : "es",
   };

  const updated = await collection.findOneAndUpdate(
    { testAccessCode : currTest.testAccessCode },
    { $set : { [`questions.${currnum}`] : newEntry }},
  );

  console.log(updated);

  res.redirect("/makertestlist");
})

router.get('/modifynewmatching', function(req, res) {
  res.render('modifynewmatching', { title: 'Modify New Matching'});
});

router.post('/modifynewmatching', async function(req, res) {
  // Get our form values. These rely on the "name" attributes
// Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  let formId = req.body.addMatching;
  let formTitle = req.body.newMatching;
  let firstKey = req.body.firstKey;
  let firstValue = req.body.firstValue;
  let secondKey = req.body.secondKey;
  let secondValue = req.body.secondValue;
  let thirdKey = req.body.thirdKey;
  let thirdValue = req.body.thirdValue;
  
  // Set our collection
  let collection = db.get('testcollection');

  // Submit to the DB
  let newEntry = {
      "formId" : formId,
      "title" : formTitle,
      "firstKey": firstKey,
      "firstValue": firstValue,
      "secondKey": secondKey,
      "secondValue": secondValue,
      "thirdKey": thirdKey,
      "thirdValue": thirdValue,
	    "type" : "ma"
  };

  const updated = await collection.findOneAndUpdate(
    { testAccessCode : currTest.testAccessCode },
    { $set : { [`questions.${currnum}`] : newEntry }},
  );

  console.log(updated);

  res.redirect("/makertestlist");
})

router.get('/modifynewRanking', function(req, res) {
  res.render('modifynewRanking', { title: 'Modify New Ranking'});
});

router.post('/modifynewranking', async function(req, res) {
  // Get our form values. These rely on the "name" attributes
  // Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  let formId = req.body.addRanking;
  let formTitle = req.body.newRanking;
  let bestChoice = req.body.bestChoice;
  let middleChoice = req.body.middleChoice;
  let worstChoice = req.body.worstChoice;

  // Set our collection
  let collection = db.get('testcollection');

  // Submit to the DB
  let newEntry = {
      "formId" : formId,
      "title" : formTitle,
      "best": bestChoice,
      "middle": middleChoice,
      "worst": worstChoice,
	    "type": "ra"
  };

  const updated = await collection.findOneAndUpdate(
    { testAccessCode : currTest.testAccessCode },
    { $set : { [`questions.${currnum}`] : newEntry }},
  );

  console.log(updated);

  res.redirect("/makertestlist");
})

router.get('/modifynewshortanswer', function(req, res) {
  res.render('modifynewshortanswer', { title: 'Modify New Short Answer'});
});

router.post('/modifynewshortanswer', async function(req, res) {
  // Get our form values. These rely on the "name" attributes
  // Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  let formId = req.body.formId;
  let formTitle = req.body.newShortAnswer;
  let minWordCount = req.body.minWordCount;
  let maxWordCount = req.body.maxWordCount;

  // Set our collection
  let collection = db.get('testcollection');

  // Submit to the DB
  let newEntry = {
      "minWordCount" : minWordCount,
      "maxWordCount" : maxWordCount,
      "formId" : formId,
      "title" : formTitle,
      "type" : "sa",
  };

  const updated = await collection.findOneAndUpdate(
    { testAccessCode : currTest.testAccessCode },
    { $set : { [`questions.${currnum}`] : newEntry }},
  );

  console.log(updated);

  res.redirect("/makertestlist");
})

router.get('/modifynewtruefalse2', function(req, res) {
  res.render('modifynewtruefalse2', { title: 'Modify New True False 2'});
});

router.post('/modifynewtruefalse2', async function(req, res) {
  // Get our form values. These rely on the "name" attributes
   // Set our internal DB variable
   let db = req.db;

   // Get our form values. These rely on the "name" attributes
   let formId2 = req.body.formId2;
   let formTitle2 = req.body.newTrueFalse2;
   let correctAnswer2 = req.body.correctAnswer2;
 
   // Set our collection
   let collection = db.get('testcollection');
 
   // Submit to the DB
   let newEntry = {
       "correctAnswer2" : correctAnswer2,
       "formId2" : formId2,
       "title2" : formTitle2,
       "type" : "tf",
   };

  const updated = await collection.findOneAndUpdate(
    { testAccessCode : currTest.testAccessCode },
    { $set : { [`questions.${currnum}`] : newEntry }},
  );

  console.log(updated);

  res.redirect("/makertestlist");
})

// SURVEYS
router.get('/modifynewmultchoice2', function(req, res) {
  res.render('modifynewmultchoice2', { title: 'Modify New Mult Choice 2 '});
});

router.post('/modifynewmultchoice2', async function(req, res) {
  // Get our form values. These rely on the "name" attributes
  let formTitle = req.body.newQuestion;
  let newChoice = req.body.mcChoice1;
  let newChoice2 = req.body.mcChoice2;
  let newChoice3 = req.body.mcChoice3;
  let newChoice4 = req.body.mcChoice4;
  let newChoice5 = req.body.mcChoice5;

  // Set our collection
  let collection = req.db.get('surveycollection');

  let newEntry = {
    "title" : formTitle,
    "choice 1": newChoice,
    "choice 2": newChoice2,
    "choice 3": newChoice3,
    "choice 4": newChoice4,
    "choice 5": newChoice5,
    "type" : "smc" 
  };

  const updated = await collection.findOneAndUpdate(
    { surveyAccessCode : currSurvey.surveyAccessCode },
    { $set : { [`questions.${currnum}`] : newEntry }},
  );

  res.redirect("/makersurveylist");
})

router.get('/modifynewtruefalse', function(req, res) {
  res.render('modifynewtruefalse', { title: 'Modify New True/False '});
});

router.post('/modifynewtruefalse', async function(req, res) {
  // Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  let formId = req.body.formId;
  let formTitle = req.body.newTrueFalse;

    // Set our collection
    let collection = db.get('surveycollection');

    // Submit to the DB
    let newSurveyTrueFalseEntry = {
        // "correctAnswer2" : correctAnswer2,
        "formId" : formId,
        "title" : formTitle,
        "type" : "stf",
    }

  const updated = await collection.findOneAndUpdate(
    { surveyAccessCode : currSurvey.surveyAccessCode },
    { $set : { [`questions.${currnum}`] : newSurveyTrueFalseEntry }},
  );

  console.log(updated);


  res.redirect("/makersurveylist");
})

router.get('/modifynewsurveyessay', function(req, res) {
  res.render('modifynewsurveyessay', { title: 'Modify New Survey Essay'});
});

router.post('/modifynewsurveyessay', async function(req, res) {
  // Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  let formId = req.body.formId;
  let formTitle = req.body.newEssay;
  let minWordCount = req.body.minWordCount;
  let maxWordCount = req.body.maxWordCount;

  // Set our collection
  // Set our collection
  let collection = db.get('surveycollection');

  // Submit to the DB
  let newSurveyEssayEntry = {
      "minWordCount" : minWordCount,
      "maxWordCount" : maxWordCount,
      "formId" : formId,
      "title" : formTitle,
      "type" : "ses",
  }

  const updated = await collection.findOneAndUpdate(
    { surveyAccessCode : currSurvey.surveyAccessCode },
    { $set : { [`questions.${currnum}`] : newSurveyEssayEntry }},
  );

  console.log(updated);


  res.redirect("/makersurveylist");
})

router.get('/modifynewsurveymatching', function(req, res) {
  res.render('modifynewsurveymatching', { title: 'Modify New Survey Matching'});
});

router.post('/modifynewsurveymatching', async function(req, res) {
  // Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  let formId = req.body.addMatching;
  let formTitle = req.body.newMatching;
  let firstKey = req.body.firstKey;
  let firstValue = req.body.firstValue;
  let secondKey = req.body.secondKey;
  let secondValue = req.body.secondValue;
  let thirdKey = req.body.thirdKey;
  let thirdValue = req.body.thirdValue;
  
  // Set our collection
  let collection = db.get('surveycollection');

  // Submit to the DB
  let newSurveyMatchingEntry = {
      "formId" : formId,
      "title" : formTitle,
      "firstKey": firstKey,
      "firstValue": firstValue,
      "secondKey": secondKey,
      "secondValue": secondValue,
      "thirdKey": thirdKey,
      "thirdValue": thirdValue,
      "type": "sma"
  }

  const updated = await collection.findOneAndUpdate(
    { surveyAccessCode : currSurvey.surveyAccessCode },
    { $set : { [`questions.${currnum}`] : newSurveyMatchingEntry }},
  );

  console.log(updated);


  res.redirect("/makersurveylist");
})

router.get('/modifynewsurveyranking', function(req, res) {
  res.render('modifynewsurveyranking', { title: 'Modify New Survey Ranking'});
});

router.post('/modifynewsurveyranking', async function(req, res) {
  // Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  let formId = req.body.addRanking;
  let formTitle = req.body.newRanking;
  let bestChoice = req.body.bestChoice;
  let middleChoice = req.body.middleChoice;
  let worstChoice = req.body.worstChoice;

  // Set our collection
  let collection = db.get('surveycollection');

  // Submit to the DB
  let newSurveyRankingEntry = {
      "formId" : formId,
      "title" : formTitle,
      "best": bestChoice,
      "middle": middleChoice,
      "worst": worstChoice,
	    "type": "sra"
  }

  const updated = await collection.findOneAndUpdate(
    { surveyAccessCode : currSurvey.surveyAccessCode },
    { $set : { [`questions.${currnum}`] : newSurveyRankingEntry }},
  );

  console.log(updated);


  res.redirect("/makersurveylist");
})

router.get('/modifynewsurveyshortanswer', function(req, res) {
  res.render('modifynewsurveyshortanswer', { title: 'Modify New Survey Short Answer'});
});

router.post('/modifynewsurveyshortanswer', async function(req, res) {
  // Set our internal DB variable
  let db = req.db;

  // Get our form values. These rely on the "name" attributes
  let formId = req.body.formId;
  let formTitle = req.body.newShortAnswer;
  let minWordCount = req.body.minWordCount;
  let maxWordCount = req.body.maxWordCount;

    // Set our collection
    let collection = db.get('surveycollection');

    // Submit to the DB
    let newSurveyShortAnswer = {
        "minWordCount" : minWordCount,
        "maxWordCount" : maxWordCount,
        "formId" : formId,
        "title" : formTitle,
        "type" : "ssa",
    }

  const updated = await collection.findOneAndUpdate(
    { surveyAccessCode : currSurvey.surveyAccessCode },
    { $set : { [`questions.${currnum}`] : newSurveyShortAnswer }},
  );

  console.log(updated);


  res.redirect("/makersurveylist");
})

router.get('/modifynewtruefalse', function(req, res) {
  res.render('modifynewtruefalse', { title: 'Modify New True False'});
});

router.get('/surveycreatesurveyview', function(req, res) {
  res.render('surveycreatesurveyview', { title: 'Survey Create Survey View'});
});

// router.get('/makersurveylist', function(req, res) {
//   res.render('makersurveylist', { title: 'Maker Survey List'});
// });

router.get('/makerenteraccesscode', function(req, res) {
  res.render('makerenteraccesscode', { title: 'Maker Survey Enter Access Code'});
});

router.get('/makersurveyenteraccesscode', function(req, res) {
  res.render('makersurveyenteraccesscode', { title: 'Maker Survey Enter Access Code'});
});

router.get('/makersurveyquestionlist', function(req, res) {
  res.render('makersurveyquestionlist', { title: 'Maker Survey Enter Access Code'});
});



/*GET generic*/
router.get('*', function(req, res) {
  res.redirect('testorsurvey');
});


module.exports = router;